package com.c4f.mvvm;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel  {
    public static MainViewModel of() {
        return ViewModelProviders.of(this).get(UserModel.class);
    }
}
